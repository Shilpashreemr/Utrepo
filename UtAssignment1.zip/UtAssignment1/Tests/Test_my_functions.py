import pytest
import Source.My_functions as My_functions
def test_AcessElementByIndex():
    index=3
    arr=[1,2,3,4]
    result= My_functions.AcessElementByIndex(arr,index)
    assert result==arr[index]

def test_IndexOutOfRange():
    with pytest.raises(IndexError):
        My_functions.AcessElementByIndex([1,2,3], 7)

def test_TypeErr():
    with pytest.raises(TypeError):
        My_functions.AcessElementByIndex( 1, 7)





