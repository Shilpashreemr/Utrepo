def AcessElementByIndex(arr,index):
    return arr[index]



